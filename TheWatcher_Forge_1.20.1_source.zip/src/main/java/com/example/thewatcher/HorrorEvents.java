package com.example.thewatcher;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Client-side atmospheric horror events. These are intentionally lightweight
 * and do not require custom entity models or external dependencies.
 */
@Mod.EventBusSubscriber(modid = TheWatcher.MODID, value = Dist.CLIENT)
public final class HorrorEvents {
    private static int tickCounter = 0;
    private static int cooldown = 20 * 45;
    private static boolean scareActive = false;
    private static int scareTicks = 0;

    private static final String[] WHISPERS = {
        "Você ouviu isso?",
        "Não olhe para trás.",
        "Tem alguém aqui com você.",
        "Você não deveria estar aqui.",
        "Eu consigo ver você.",
        "Por que você parou?",
        "Ele está mais perto agora."
    };

    private HorrorEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || mc.isPaused()) return;

        tickCounter++;

        if (scareActive) {
            scareTicks--;
            if (scareTicks <= 0) {
                scareActive = false;
            }
        }

        // Random atmospheric events, only while the player is in-world.
        if (--cooldown <= 0) {
            RandomSource random = player.getRandom();
            cooldown = 20 * (55 + random.nextInt(100));

            // Keep most events rare and avoid repeatedly interrupting gameplay.
            int event = random.nextInt(4);
            if (event == 0) {
                String whisper = WHISPERS[random.nextInt(WHISPERS.length)];
                player.displayClientMessage(
                    Component.literal("§8[ sussurro ] §7" + whisper).withStyle(ChatFormatting.DARK_GRAY),
                    true
                );
            } else if (event == 1 && player.level().isNight()) {
                player.playSound(SoundEvents.AMBIENT_CAVE, 0.7F, 0.55F + random.nextFloat() * 0.25F);
                player.displayClientMessage(
                    Component.literal("§4Algo se moveu na escuridão..."),
                    true
                );
            } else if (event == 2 && player.level().getMaxLocalRawBrightness(player.blockPosition()) < 7) {
                player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 35, 0, false, false, false));
                player.playSound(SoundEvents.SCULK_SHRIEKER_SHRIEK, 0.35F, 0.65F);
            }
        }
    }

    /** Called by /terror; the command implementation lives in HorrorCommand. */
    public static void triggerScare(LocalPlayer player) {
        if (player == null) return;
        scareActive = true;
        scareTicks = 50;

        player.displayClientMessage(
            Component.literal("§4§lNÃO SE MOVA.").withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD),
            false
        );
        player.playSound(SoundEvents.WARDEN_ROAR, 0.9F, 0.7F);
        player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 35, 0, false, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 55, 0, false, false, false));
    }
}
