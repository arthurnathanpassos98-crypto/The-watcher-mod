package com.example.thewatcher;

import com.mojang.brigadier.Command;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * The command gives a short creepy warning. The client-side effect is triggered
 * by the client tick handler when requested through the local command.
 */
@Mod.EventBusSubscriber(modid = TheWatcher.MODID, value = Dist.CLIENT)
public final class HorrorCommand {
    private HorrorCommand() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        // Commands are registered on the logical server. The /terror command
        // is implemented as a server command below and displays a safe message.
        event.getDispatcher().register(
            Commands.literal("terror")
                .requires(source -> source.hasPermission(0))
                .executes(context -> {
                    context.getSource().sendSuccess(
                        () -> Component.literal("§4A presença percebeu você. §7(Os eventos aleatórios continuam...)"),
                        false
                    );
                    return Command.SINGLE_SUCCESS;
                })
        );
    }
}
