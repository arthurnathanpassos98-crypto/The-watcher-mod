# The Watcher — Forge 1.20.1

Mod de terror atmosférico para Minecraft Java Edition 1.20.1 com Forge 47.2.0.

## O que esta primeira versão inclui
- Mensagens misteriosas ocasionais na tela.
- Sons de caverna e sons sinistros durante eventos raros.
- Efeito de escuridão em locais muito escuros.
- Comando `/terror` para uma mensagem de aviso.

## Requisitos
- Minecraft Java Edition 1.20.1
- Forge 1.20.1 (ramo 47.x)
- Java 17 para compilar o projeto
- Para jogar no Android, um launcher compatível com Forge e Java 17.

## Como compilar
1. Extraia o ZIP em um computador ou ambiente que tenha Java 17 e acesso à internet.
2. Abra um terminal dentro da pasta do projeto.
3. Execute `gradle build` (ou `./gradlew build` se adicionar o Gradle Wrapper).
4. O JAR compilado deverá aparecer em `build/libs/`.

## Instalação no launcher
Copie o JAR compilado para a pasta `mods` do perfil Minecraft 1.20.1 Forge.

## Observações
Este ZIP contém o código-fonte do mod, não um JAR já compilado. A compilação requer baixar ForgeGradle e as dependências.
O comando `/terror` desta versão inicial é um aviso de texto; os efeitos atmosféricos aleatórios funcionam independentemente dele.
